# __init__.py

from .mind_reader import tricky

__all__ = ['tricky']